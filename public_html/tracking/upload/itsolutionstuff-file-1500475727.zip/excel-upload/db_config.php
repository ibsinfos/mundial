<?php
	$dbHost = "localhost";
	$dbDatabase = "h_php";
	$dbPasswrod = "root";
	$dbUser = "root";
	$mysqli = new mysqli($dbHost, $dbUser, $dbPasswrod, $dbDatabase);
?>